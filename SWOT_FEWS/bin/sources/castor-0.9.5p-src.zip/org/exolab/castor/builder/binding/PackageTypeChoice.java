/*
 * This class was automatically generated with 
 * <a href="http://castor.exolab.org">Castor 0.9.4</a>, using an
 * XML Schema.
 * $Id: PackageTypeChoice.java,v 1.1.1.1 2003/03/03 07:07:53 kvisco Exp $
 */

package org.exolab.castor.builder.binding;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.*;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * 
 * 
 * @version $Revision: 1.1.1.1 $ $Date: 2003/03/03 07:07:53 $
**/
public class PackageTypeChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    private java.lang.String _namespace;

    private java.lang.String _schemaLocation;


      //----------------/
     //- Constructors -/
    //----------------/

    public PackageTypeChoice() {
        super();
    } //-- org.exolab.castor.builder.binding.PackageTypeChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'namespace'.
     * 
     * @return the value of field 'namespace'.
    **/
    public java.lang.String getNamespace()
    {
        return this._namespace;
    } //-- java.lang.String getNamespace() 

    /**
     * Returns the value of field 'schemaLocation'.
     * 
     * @return the value of field 'schemaLocation'.
    **/
    public java.lang.String getSchemaLocation()
    {
        return this._schemaLocation;
    } //-- java.lang.String getSchemaLocation() 

    /**
    **/
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * 
     * 
     * @param out
    **/
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * 
     * 
     * @param handler
    **/
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'namespace'.
     * 
     * @param namespace the value of field 'namespace'.
    **/
    public void setNamespace(java.lang.String namespace)
    {
        this._namespace = namespace;
    } //-- void setNamespace(java.lang.String) 

    /**
     * Sets the value of field 'schemaLocation'.
     * 
     * @param schemaLocation the value of field 'schemaLocation'.
    **/
    public void setSchemaLocation(java.lang.String schemaLocation)
    {
        this._schemaLocation = schemaLocation;
    } //-- void setSchemaLocation(java.lang.String) 

    /**
     * 
     * 
     * @param reader
    **/
    public static org.exolab.castor.builder.binding.PackageTypeChoice unmarshalPackageTypeChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.exolab.castor.builder.binding.PackageTypeChoice) Unmarshaller.unmarshal(org.exolab.castor.builder.binding.PackageTypeChoice.class, reader);
    } //-- org.exolab.castor.builder.binding.PackageTypeChoice unmarshalPackageTypeChoice(java.io.Reader) 

    /**
    **/
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
