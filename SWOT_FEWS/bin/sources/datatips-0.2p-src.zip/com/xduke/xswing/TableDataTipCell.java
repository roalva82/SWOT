/*
 * Copyright (c) 2002 - 2005, Stephen Kelvin Friedrich. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or other
 *   materials provided with the distribution.
 * - Neither the name of the copyright holder nor the names of its contributors may be
 *   used to endorse or promote products derived from this software without specific
 *   prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package com.xduke.xswing;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.TableCellRenderer;
import javax.swing.text.*;
import java.awt.*;

class TableDataTipCell implements DataTipCell {
    private final JTable table;
    private final int rowIndex;
    private final int columnIndex;

    TableDataTipCell(JTable table, int rowIndex, int columnIndex) {
        this.table = table;
        this.rowIndex = rowIndex;
        this.columnIndex = columnIndex;
    }

    public boolean isSet() {
        return rowIndex >= 0 && columnIndex >= 0;
    }

    public Rectangle getCellBounds() {
        return table.getCellRect(rowIndex, columnIndex, false);
    }

    @Override
    public Component getRendererComponent() {
        if (rowIndex >= table.getRowCount() || columnIndex >= table.getColumnCount())  {
            // prevent index out of bound exception added by OA
            JLabel res = new JLabel();
            res.setMinimumSize(new Dimension(1, 1));
            return res;
        }

        TableCellRenderer cellRenderer = table.getCellRenderer(rowIndex, columnIndex);
        Component component = table.prepareRenderer(cellRenderer, rowIndex, columnIndex);
        if (!(cellRenderer instanceof JLabel) || !table.isShowing()) return component;
        // rest of method added by OA

        JLabel label = (JLabel) cellRenderer;
        if (label.getHorizontalAlignment() == SwingConstants.RIGHT || label.getIcon() != null) {
            component.setMinimumSize(new Dimension(1, 1));
            return component;
        }

        final Rectangle cellRect = table.getCellRect(rowIndex, columnIndex, false);

        JTextPane res = new JTextPane();
        res.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, true);
        res.setBorder(new LineBorder(Color.RED, 1) {
            @Override
            public Insets getBorderInsets(Component c, Insets insets) {
                insets.set(-1, 1, 0, 4);
                return insets;
            }

            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Color oldColor = g.getColor();
                g.setColor(this.lineColor);
                g.drawLine(x + cellRect.width, y, x + width, y);
                boolean multipleLines = height > cellRect.height;
                int left = multipleLines ? x :  x + cellRect.width;
                g.drawLine(left, y + height - 1, x + width, y + height - 1);
                g.drawLine(x + width - 1, y, x + width - 1, y + height - 1);
                if (multipleLines) g.drawLine(x, y + cellRect.height, x, y + height - 1);
                g.setColor(oldColor);
            }
        });
        res.setEditorKit(new WrapEditorKit());
        String text = label.getText();
        if (text != null && text.startsWith("<html>")) res.setContentType("text/html");
        res.setText(text);
        res.setFont(label.getFont());
        res.setSize(getMaxDataTipRectangle().getSize().width, Integer.MAX_VALUE);
        res.setBackground(label.getBackground());
        res.setForeground(label.getForeground());
        Dimension preferredSize = res.getPreferredSize();
        res.setMinimumSize(preferredSize);

        if (preferredSize.getWidth() <= cellRect.getWidth() && preferredSize.getHeight() <= cellRect.getHeight() && table.getVisibleRect().contains(cellRect)) {
            component.setMinimumSize(new Dimension(1, 1));
            return component;
        }

        return res;
    }

    public Rectangle getMaxDataTipRectangle() {
        Rectangle cellRectangle = table.getCellRect(rowIndex, columnIndex, false);
        Point locationOnScreen = table.getLocationOnScreen();
        Rectangle res = new Rectangle(locationOnScreen.x + cellRectangle.x, locationOnScreen.y + cellRectangle.y, 100000, 10000);
        return res.intersection(getScreenBounds());
    }

    private Rectangle getScreenBounds() {
        Window windowAncestor = SwingUtilities.getWindowAncestor(table);
        GraphicsConfiguration gc = windowAncestor.getGraphicsConfiguration();
        return gc.getBounds();
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        TableDataTipCell cellPosition = (TableDataTipCell) o;

        if (columnIndex != cellPosition.columnIndex) {
            return false;
        }
        if (rowIndex != cellPosition.rowIndex) {
            return false;
        }

        return true;
    }

    public int hashCode() {
        int result;
        result = rowIndex;
        result = 29 * result + columnIndex;
        return result;
    }

    // Rest Added by OA

    // Tricks to get the wrapping right
    // see https://community.oracle.com/message/10759680
    private static class WrapEditorKit extends StyledEditorKit {
        ViewFactory defaultFactory = new WrapColumnFactory();

        @Override
        public ViewFactory getViewFactory() {
            return defaultFactory;
        }
    }

    private static class WrapColumnFactory implements ViewFactory {
        @Override
        public View create(Element elem) {
            String kind = elem.getName();
            if (kind != null) {
                if (kind.equals(AbstractDocument.ContentElementName)) {
                    return new WrapLabelView(elem);
                } else if (kind.equals(AbstractDocument.ParagraphElementName)) {
                    return new ParagraphView(elem);
                } else if (kind.equals(AbstractDocument.SectionElementName)) {
                    return new BoxView(elem, View.Y_AXIS);
                } else if (kind.equals(StyleConstants.ComponentElementName)) {
                    return new ComponentView(elem);
                } else if (kind.equals(StyleConstants.IconElementName)) {
                    return new IconView(elem);
                }
            }

            // default to text display
            return new LabelView(elem);
        }
    }

    private  static class WrapLabelView extends LabelView {
        private WrapLabelView(Element elem) {
            super(elem);
        }

        @Override
        public float getMinimumSpan(int axis) {
            switch (axis) {
                case View.X_AXIS:
                    return 0;
                case View.Y_AXIS:
                    return super.getMinimumSpan(axis);
                default:
                    throw new IllegalArgumentException("Invalid axis: " + axis);
            }
        }
    }
}
