/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 * <p/>
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * <p/>
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

package skt.swing;

import skt.swing.scroll.ScrollGestureRecognizer;

/**
 * installs MySwing Utilities
 *
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
public class MySwing{
    public static void install(){
        ActiveWindowTracker.class.getName();
        ScrollGestureRecognizer.class.getName();
    }
}