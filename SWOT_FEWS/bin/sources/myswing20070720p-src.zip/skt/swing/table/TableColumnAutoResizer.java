package skt.swing.table;

/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.*;

/**
 * Allows table columns to be resized to its preferred width
 * by double-clicking at the column-splitter in table header.
 *
 * the preferred width here is the min width reqd to make the
 * data of all rows of that column visible
 *
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
public class TableColumnAutoResizer extends MouseAdapter{
    public void mouseClicked(MouseEvent e){
        if(e.getClickCount()!=2)
            return;

        JTableHeader header = (JTableHeader)e.getSource();
        TableColumn tableColumn = getResizingColumn(header, e.getPoint());
        if(tableColumn==null)
            return;
        int col = header.getColumnModel().getColumnIndex(tableColumn.getIdentifier());
        JTable table = header.getTable();
        int rowCount = table.getRowCount();
        int width = (int)header.getDefaultRenderer()
                .getTableCellRendererComponent(table, tableColumn.getIdentifier()
                        , false, false, -1, col).getPreferredSize().getWidth();
        for(int row = 0; row<rowCount; row++){
            int preferedWidth = (int)table.getCellRenderer(row, col).getTableCellRendererComponent(table,
                    table.getValueAt(row, col), false, false, row, col).getPreferredSize().getWidth();
            width = Math.max(width, preferedWidth);
        }
        header.setResizingColumn(tableColumn); // this line is very important
        tableColumn.setWidth(width+table.getIntercellSpacing().width);
    }

    // copied of BasicTableHeader.MouseInputHandler.getResizingColumn
    private TableColumn getResizingColumn(JTableHeader header, Point p){
        return getResizingColumn(header, p, header.columnAtPoint(p));
    }

    // copied of BasicTableHeader.MouseInputHandler.getResizingColumn
    private TableColumn getResizingColumn(JTableHeader header, Point p, int column){
        if(column==-1){
            return null;
        }
        Rectangle r = header.getHeaderRect(column);
        r.grow(-3, 0);
        if(r.contains(p))
            return null;
        int midPoint = r.x+r.width/2;
        int columnIndex;
        if(header.getComponentOrientation().isLeftToRight())
            columnIndex = (p.x<midPoint) ? column-1 : column;
        else
            columnIndex = (p.x<midPoint) ? column : column-1;
        if(columnIndex==-1)
            return null;
        return header.getColumnModel().getColumn(columnIndex);
    }
}