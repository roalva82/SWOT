package skt.swing.search;

/**
 * MySwing: Advanced Swing Utilites
 * Copyright (C) 2005  Santhosh Kumar T
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 */

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.text.Position;
import java.awt.*;
import java.awt.event.*;
import java.util.ResourceBundle;
import java.util.Locale;

/**
 * @author Santhosh Kumar T
 * @email  santhosh@in.fiorano.com
 */
public abstract class FindAction extends AbstractAction implements DocumentListener, KeyListener, PopupMenuListener{

    private static final ResourceBundle BUNDLE = ResourceBundle.getBundle(FindAction.class.getName(), Locale.getDefault());

    private JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    private JPopupMenu popup = new JPopupMenu();

    protected JTextField searchField = new JTextField();
    protected boolean ignoreCase;

    // component on which search is taking place
    protected JComponent comp = null;

    public FindAction(boolean ignoreCase){
        super("incremantal-search-case"+(ignoreCase ? "in" : "")+"sensitive");
        this.ignoreCase = ignoreCase;

        int modifiers = KeyEvent.CTRL_MASK;
        if(ignoreCase)
            modifiers = modifiers | KeyEvent.SHIFT_MASK;
        putValue(Action.ACCELERATOR_KEY,   KeyStroke.getKeyStroke('I', modifiers));

        createSearchPanel();
    }

    private void createSearchPanel(){
        searchPanel.setBackground(UIManager.getColor("ToolTip.background")); //NOI18N
        searchField.setOpaque(false);
        JLabel label = new JLabel(BUNDLE.getString("search"));
        label.setFont(new Font("DialogInput", Font.BOLD, 12)); // for readability
        searchPanel.add(label);
        searchPanel.add(searchField);
        searchField.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
        searchPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        popup.setBorder(BorderFactory.createLineBorder(Color.black));
        popup.add(searchPanel);
        popup.addPopupMenuListener(this);
        searchField.setFont(new Font("DialogInput", Font.PLAIN, 12)); // for readability

        // when the window containing the "comp" has registered Esc key
        // then on pressing Esc instead of search popup getting closed
        // the event is sent to the window. to overcome this we
        // register an action for Esc.
        searchField.registerKeyboardAction(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                UIManager.getDefaults().put("TextField.patchSelectOnFocus", Boolean.TRUE); // added by OA, winlaf fix
                popup.setVisible(false);
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_FOCUSED);
    }

    /*-------------------------------------------------[ ActionListener ]---------------------------------------------------*/

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == searchField){
            UIManager.getDefaults().put("TextField.patchSelectOnFocus", Boolean.TRUE); // added by OA, winlaf fix
            popup.setVisible(false);
            comp = null; // favor GC
        }else{
            comp = (JComponent)ae.getSource();

            searchField.removeActionListener(this);
            searchField.removeKeyListener(this);
            searchField.getDocument().removeDocumentListener(this);
            initSearch(ae);
            searchField.addActionListener(this);
            searchField.addKeyListener(this);
            searchField.getDocument().addDocumentListener(this);

            Rectangle rect = comp.getVisibleRect();
            popup.show(comp, rect.x, rect.y - popup.getPreferredSize().height - 5);
            UIManager.getDefaults().put("TextField.patchSelectOnFocus", Boolean.FALSE); // added by OA, winlaf fix
            searchField.requestFocus();
        }
    }

    // can be overridden by subclasses to change initial search text etc.
    protected void initSearch(ActionEvent ae){
        searchField.setText(""); //NOI18N
        searchField.setForeground(Color.black);
    }

    private void changed(Position.Bias bias){
        // note: popup.pack() doesn't work for first character insert
        popup.setVisible(false);
        popup.setVisible(true);

        UIManager.getDefaults().put("TextField.patchSelectOnFocus", Boolean.FALSE); // added by OA, winlaf fix
        searchField.requestFocus();

        searchField.setForeground(changed(comp, searchField.getText(), bias) ? Color.black : Color.red);
    }

    // should search for given text and select item and
    // return true if search is successfull
    protected abstract boolean changed(JComponent comp, String text, Position.Bias bias);

    /*-------------------------------------------------[ DocumentListener ]---------------------------------------------------*/

    public void insertUpdate(DocumentEvent e){
        changed(null);
    }

    public void removeUpdate(DocumentEvent e){
        changed(null);
    }

    public void changedUpdate(DocumentEvent e){}

    /*-------------------------------------------------[ KeyListener ]---------------------------------------------------*/

    protected boolean shiftDown = false;
    protected boolean controlDown = false;

    public void keyPressed(KeyEvent ke){
        shiftDown = ke.isShiftDown();
        controlDown = ke.isControlDown();

        switch(ke.getKeyCode()){
            case KeyEvent.VK_UP:
                changed(Position.Bias.Backward);
                break;
            case KeyEvent.VK_DOWN:
                changed(Position.Bias.Forward);
                break;
        }
    }

    public void keyTyped(KeyEvent e){}
    public void keyReleased(KeyEvent e){}

    /*-------------------------------------------------[ PopupMenuListener ]---------------------------------------------------*/
    public void popupMenuWillBecomeVisible(PopupMenuEvent e){}
    public void popupMenuWillBecomeInvisible(PopupMenuEvent e){
        comp.requestFocus();
//        comp = null; //favor gc
    }
    public void popupMenuCanceled(PopupMenuEvent e){
        System.err.println("cancelled");
    }
}